package Principal;

import java.util.Scanner;

enum Categoria {Jefe,Empleado}

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		String opcion;
		Persona p;
		
		Gestor gestor = new Gestor();
		Impresora impresoraBN = new Impresora("BN_1",gestor);
		
		gestor.addImpresora(impresoraBN); // Añade y arranca la impresora
		
		do
		{
			opcion = menu(sc);
			switch (opcion)
			{
			case "E":
				p = new Persona(gestor,Categoria.Empleado);
				p.start();
				break;
			case "J":
				p = new Persona(gestor,Categoria.Jefe);
				p.start();
				break;
			}
		} while (!opcion.equals("F"));
		impresoraBN.apagar();
		impresoraBN.interrupt();
		sc.close();
	}
	
	public static String menu (Scanner sc)
	{
		String opcion;
		System.out.println("Añadir (E)mpleado (J)efe. (F)in");
		opcion = sc.nextLine();
		opcion = opcion.toUpperCase().substring(0,1);
		return opcion;
	}
}