package Principal;

public class Persona extends Thread
{
	private Gestor gestor;
	private Categoria categoria;
	
	public Persona(Gestor gestor,Categoria categoria)
	{
		this.gestor = gestor;
		this.categoria = categoria;
	}
	
	public Categoria getCategoria()
	{
		return this.categoria;
	}
	
	public void run()
	{
		gestor.imprimir();
	}
}
