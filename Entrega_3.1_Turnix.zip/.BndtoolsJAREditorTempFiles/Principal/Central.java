package Principal;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;

public class Central 
{
	private ArrayList<Turno> peticiones;
	private ArrayList<Turno> funcionarios;
	
	// Para poder detener los hilos y el servidor en cualquier momento
	private ArrayList<HiloTurno> hilos;
	private ServerSocket socketServidor;
	
	public Central(ServerSocket socketServidor)
	{
		this.peticiones = new ArrayList<>();
		this.funcionarios = new ArrayList<>();
		this.hilos = new ArrayList<>();
		this.socketServidor = socketServidor;
	}
	
	public synchronized void serAtendido(Turno turno,HiloTurno hilo) throws InterruptedException
	{
		Turno funcionario;
		hilos.add(hilo);
		peticiones.add(turno);
		while ((funcionario = buscarFuncionarioXConcepto(turno))==null)
			wait();
		System.out.println("Acabamos de emparejar "+turno+" con "+funcionario);
		peticiones.remove(turno);
		funcionarios.remove(funcionario);
		notifyAll();
	}
	
	public synchronized void Atender(Turno turno,HiloTurno hilo) throws InterruptedException
	{
		hilos.add(hilo);
		funcionarios.add(turno);
		notifyAll();
		while (funcionarios.contains(turno))
			wait();
	}
	
	public synchronized void finalizarHilo(HiloTurno hilo)
	{
		hilos.remove(hilo);
	}
	
	public synchronized void verListadoFuncionarios()
	{
		System.out.println("Listado de funcionarios");
		System.out.println("=======================");
		for (Turno t: funcionarios)
			System.out.println(t);
	}
	
	public synchronized void terminar()
	{
		for (HiloTurno h:hilos)
			h.interrupt();
		try 
		{
			this.socketServidor.close();
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public synchronized Turno buscarFuncionarioXConcepto(Turno turno)
	{
		Turno funcionario = null;
		for (Turno t : funcionarios)
			if (t.getConcepto().equals(turno.getConcepto()))
				return t;
		return funcionario;
	}
}
