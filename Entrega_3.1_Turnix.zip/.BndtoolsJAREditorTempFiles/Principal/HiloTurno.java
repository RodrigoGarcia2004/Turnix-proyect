package Principal;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

public class HiloTurno extends Thread
{
	private Socket socket;
	private Central central;
	
	private InputStream flujoEntrada;
	private OutputStream flujoSalida;
	private ObjectInputStream entrada;
	private ObjectOutputStream salida;
	
	public HiloTurno (Socket socket,Central central) throws IOException
	{
		this.socket = socket;
		this.central = central;
		
		flujoEntrada = socket.getInputStream();
		flujoSalida = socket.getOutputStream();
		entrada = new ObjectInputStream(flujoEntrada);
		salida = new ObjectOutputStream(flujoSalida);
	}
	
	public void run()
	{
		Turno turno = null;
		try 
		{
			turno = recibirTurno();
			switch (turno.getTipo())
			{
			case 0: 

				central.serAtendido(turno, this);
				break;
			case 1:
				central.Atender(turno, this);
				break;
			}
		} catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} catch (IOException | InterruptedException e) 
		{
			System.out.println("Se ha interrumpido un HiloTurno");
		}
		central.finalizarHilo(this);
	}
	
	public void enviarTurno (Turno turno) throws IOException
	{
		salida.writeObject(turno);
		salida.flush();
	}
	
	public Turno recibirTurno () throws ClassNotFoundException, IOException
	{
		Turno turno;
		turno = (Turno) entrada.readObject();
		return turno;
	}
	
	public void cerrar () throws IOException
	{
		salida.close();
		entrada.close();
		flujoSalida.close();
		flujoEntrada.close();
		socket.close();
	}
}
