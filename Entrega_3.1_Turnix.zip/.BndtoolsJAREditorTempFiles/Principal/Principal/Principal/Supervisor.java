package Principal;

import java.util.Scanner;

public class Supervisor extends Thread
{
	private Scanner sc;
	private Central central;
	
	public Supervisor (Scanner sc,Central central)
	{
		this.sc = sc;
		this.central = central;
	}
	
	public void run ()
	{
		String comando;
		boolean fin = false;
		do
		{
			System.out.println("Introduzca comando (LISTADO, CERRAR)");
			comando = sc.nextLine().toUpperCase();
			switch (comando)
			{
			case "LISTADO":
				central.verListadoFuncionarios();
				break;
			case "CERRAR":
				central.terminar();
				fin = true;
				break;
			}
		} while (!fin);
	}
}
