package Principal;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;

public class ServidorTurnos 
{
	public static void main(String[] args) throws IOException 
	{
		// Socket de servidor y de cliente
		ServerSocket socketServidor = new ServerSocket(9000);
		Socket socketCliente;
		boolean fin = false;
		
		// Recurso común para sincronización 
		Central central = new Central(socketServidor);
		HiloTurno hilo;
		
		// Teclado e hilo supervisor
		Scanner teclado = new Scanner(System.in);
		Supervisor supervisor = new Supervisor(teclado,central);
		supervisor.start();
		
		while (!fin)
		{
			try
			{
				socketCliente = socketServidor.accept();
				hilo = new HiloTurno(socketCliente,central);
				hilo.start();
			} catch (SocketException e) 
			{
				System.out.println("Se ha detenido el servidor");
				fin = true;
			}
		}
		socketServidor.close();
		teclado.close();
	}
}
