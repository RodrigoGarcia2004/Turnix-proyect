package Principal;

public class Impresora extends Thread 
{
	private String nombre;
	private boolean ocupada;
	private boolean apagada;
	private Gestor gestor;
	
	public Impresora (String nombre,Gestor gestor)
	{
		this.nombre = nombre;
		this.gestor = gestor;
		this.apagada = false;
		this.ocupada = false;
	}
	
	public void run()
	{
		System.out.println("Impresora "+nombre+" en marcha.");
		while (!apagada)
		{
			gestor.obtenerTrabajo(this);
			System.out.println("Impresora imprimiendo trabajo");
			try 
			{
				Thread.sleep(2000);
			}
			catch (InterruptedException e) {e.printStackTrace();} // Simulamos el tiempo de impresión
			gestor.finImpresion(this);
		}
	}
	
	public boolean getOcupada()
	{
		return this.ocupada;
	}
	
	public void setOcupada(boolean ocupada)
	{
		this.ocupada = ocupada;
	}
	
	public void apagar ()
	{
		this.apagada = true;
	}
}
