package Principal;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Gestor 
{
	private ReentrantLock lock;
	private Condition colaImpresoras;
	private Condition colaEmpleados;
	private Condition colaJefes;

	private int nJefesEsperando;
	private int nEmpleadosEsperando;
	private Impresora impresora;
	
	public Gestor()
	{
		this.lock = new ReentrantLock();
		this.colaImpresoras = lock.newCondition();
		this.colaEmpleados = lock.newCondition();
		this.colaJefes = lock.newCondition();
		
		this.nJefesEsperando = 0;
		this.nEmpleadosEsperando = 0;
	}
	
	public void addImpresora(Impresora impresora)
	{
		if (this.impresora == null)
		{
			this.impresora = impresora;
			impresora.start();
		}
	}
	
	public void imprimir()
	{
		Persona persona = (Persona) Thread.currentThread();
		Categoria categoria = persona.getCategoria();
		
		lock.lock();
		try
		{
			switch (categoria)
			{
			case Jefe:
				nJefesEsperando++;
				System.out.println(nJefesEsperando+" Jefes esperando");
				while (impresora.getOcupada())
				{
					System.out.println("Jefe en cola");
					colaJefes.await();
				}
				impresora.setOcupada(true);
				nJefesEsperando--;
				colaImpresoras.signal();
				System.out.println(nJefesEsperando+" Jefes esperando");
				break;
			case Empleado:
				nEmpleadosEsperando++;
				System.out.println(nEmpleadosEsperando+" Empleados esperando");
				while (impresora.getOcupada() || nJefesEsperando>0)
					colaEmpleados.await();
				
				impresora.setOcupada(true);
				nEmpleadosEsperando--;
				colaImpresoras.signal();
				System.out.println(nEmpleadosEsperando+" Empleados esperando");
				break;
			}
		} 
		catch (InterruptedException e) {e.printStackTrace();}
		finally {lock.unlock();}
	}
	
	public void obtenerTrabajo(Impresora impresora) 
	{
		try 
		{
			lock.lockInterruptibly();
			colaImpresoras.await();
		} 
		catch (InterruptedException e)
		{System.out.println("Han interrumpido");}
		finally
		{
			if (lock.isHeldByCurrentThread()) 
				lock.unlock();
		}
	}
	
	public void finImpresion(Impresora impresora)
	{
		lock.lock();
		System.out.println("Impresora fin de impresión");
		impresora.setOcupada(false);
		
		if (nJefesEsperando>0)
			colaJefes.signal();
		else
			if (nEmpleadosEsperando > 0)
				colaEmpleados.signal();
		lock.unlock();
	}
}