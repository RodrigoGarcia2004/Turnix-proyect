<?php
echo "PHP FUNCIONA";
?>