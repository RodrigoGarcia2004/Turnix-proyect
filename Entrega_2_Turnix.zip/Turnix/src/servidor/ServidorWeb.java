package servidor;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import java.net.InetSocketAddress;
import java.util.LinkedList;
import java.util.Queue;
import database.UsuarioDAO;
import modelo.Usuario;

public class ServidorWeb extends WebSocketServer {

    // --- NUEVA IMPLEMENTACIÓN: Gestión de cola cronológica ---
    private Queue<WebSocket> colaEspera = new LinkedList<>();

    public ServidorWeb(int puerto) {
        super(new InetSocketAddress(puerto));
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
        System.out.println("Nueva conexión detectada: " + conn.getRemoteSocketAddress());
    }

    @Override
    public void onMessage(WebSocket conn, String message) {
        System.out.println("📥 Mensaje recibido: " + message);

     // --- 1. LÓGICA DE LOGIN ---
        if (message.startsWith("login:")) {
            String[] datos = message.split(":");
            if (datos.length >= 3) {
                try {
                    Usuario u = UsuarioDAO.autenticar(datos[1], datos[2]);
                    
                    if (u != null) {
                        // Extraemos el nombre para mostrar (evitando el "null" de la BD)
                        String nombreAMostrar = (u.getNombreCompleto() != null && !u.getNombreCompleto().equals("null")) 
                                                ? u.getNombreCompleto() : u.getUsername();

                        // --- MEJORA DE SEGURIDAD: Validación de Rol por Portal ---
                        // Si el usuario es médico, solo debería entrar si el sistema lo permite.
                        // Aquí enviamos el LOGIN_OK pero el JavaScript del index.html 
                        // debe decidir si le deja pasar según el panel.
                        
                        conn.setAttachment(u); // Guardamos la sesión
                        conn.send("LOGIN_OK:" + u.getRol() + ":" + nombreAMostrar);
                        System.out.println("✅ Login exitoso: " + nombreAMostrar + " (Rol: " + u.getRol() + ")");
                        
                    } else {
                        // Si el DAO devuelve null, es que las credenciales no existen
                        conn.send("ERROR: Usuario o clave incorrectos");
                        System.out.println("❌ Intento de login fallido: " + datos[1]);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    conn.send("ERROR: Fallo en el sistema de autenticación");
                }
            }
        } 

        // --- 1.5 LÓGICA DE REGISTRO ---
        else if (message.startsWith("registro:")) {
            String[] datos = message.split(":");
            if (datos.length >= 4) {
                System.out.println("⚙️ Procesando registro para: " + datos[1]);
                try {
                    boolean exito = UsuarioDAO.registrar(datos[1], datos[2], datos[3]);
                    if (exito) {
                        conn.send("REGISTRO_OK");
                        System.out.println("✅ Registro completado en BD");
                    } else {
                        conn.send("REGISTRO_ERROR: No se pudo crear la cuenta (posible usuario duplicado)");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    conn.send("REGISTRO_ERROR: Error interno en el servidor");
                }
            }
        }

        // --- 2. LÓGICA DE PEDIR TURNO (CON COLA) ---
     // --- 2. LÓGICA DE PEDIR TURNO (CON BLOQUEO DE DUPLICADOS) ---
        else if (message.equals("PEDIR_TURNO")) {
            Usuario u = (Usuario) conn.getAttachment(); 
            
            if (u != null) {
                // VERIFICACIÓN: ¿Ya está este usuario en la cola?
                boolean yaTieneTurno = false;
                for (WebSocket ws : colaEspera) {
                    Usuario usuarioEnCola = ws.getAttachment();
                    if (usuarioEnCola != null && usuarioEnCola.getId() == u.getId()) {
                        yaTieneTurno = true;
                        break;
                    }
                }

                if (yaTieneTurno) {
                    System.out.println("⚠️ Intento de duplicado: " + u.getUsername() + " ya tiene un turno.");
                    conn.send("ERROR: Ya tienes un turno solicitado. Espera a ser llamado.");
                } else {
                    // Si no tiene turno, procedemos a darle uno
                    String nombre = (u.getNombreCompleto() != null && !u.getNombreCompleto().equals("null")) 
                                    ? u.getNombreCompleto() : u.getUsername();
                    
                    modelo.Turno t = database.GestorTurnos.pedirTurno(nombre);
                    
                    if (t != null) {
                        colaEspera.add(conn); // Añadimos la conexión actual a la cola
                        String mensajeAviso = "TURNO_ASIGNADO: " + nombre + " (Turno #" + t.getNumeroTurno() + ")";
                        
                        // Notificamos a todos
                        for (WebSocket client : getConnections()) {
                            client.send(mensajeAviso);
                        }
                        System.out.println("📢 Turno concedido a: " + nombre);
                    } else {
                        conn.send("ERROR: Error al generar turno en base de datos.");
                    }
                }
            } else {
                conn.send("ERROR: Debes iniciar sesión para pedir turno.");
            }
        }

        // --- 3. LÓGICA DE LLAMAR SIGUIENTE (MÉDICO) ---
        else if (message.equals("LLAMAR_SIGUIENTE")) {
            System.out.println("📢 El médico ha pulsado 'Siguiente'");
            if (!colaEspera.isEmpty()) {
                // CAMBIAMOS peek() POR poll()
                WebSocket pacienteConn = colaEspera.poll(); 
                actualizarPosicionesCola();
                if (pacienteConn != null && pacienteConn.isOpen()) {
                    pacienteConn.send("SISTEMA: LLAMADA_A_CONSULTA");
                    System.out.println("✅ Paciente extraído de la cola y avisado.");
                }
            } else {
                conn.send("ERROR: No hay nadie esperando.");
            }
        }

        // --- 4. CHAT: MÉDICO -> PACIENTE ---
        else if (message.startsWith("CHAT_PRIVADO:")) {
            String[] partes = message.split(":", 3);
            if (partes.length >= 3) {
                String nombreDestino = partes[1];
                String texto = partes[2];
                boolean encontrado = false;

                for (WebSocket client : getConnections()) {
                    Usuario userClient = client.getAttachment();
                    if (userClient != null) {
                        String nombreClient = (userClient.getNombreCompleto() != null && !userClient.getNombreCompleto().equals("null")) 
                                              ? userClient.getNombreCompleto() : userClient.getUsername();

                        if (nombreClient.equals(nombreDestino)) {
                            client.send("MEDICO_DICE:" + texto);
                            encontrado = true;
                            break;
                        }
                    }
                }
                if (!encontrado) conn.send("SISTEMA: El paciente no está conectado.");            
                }
        }

        // --- 5. CHAT: PACIENTE -> MÉDICO ---
        else if (message.startsWith("ENVIAR_AL_MEDICO:")) {
            // 1. Extraemos el mensaje de forma segura usando substring
            // Esto evita que se borre texto si el paciente escribe "ENVIAR_AL_MEDICO:" dentro del mensaje
            String texto = message.substring("ENVIAR_AL_MEDICO:".length()).trim();
            
            boolean entregado = false;
            int medicosActivos = 0;

            // 2. Recorremos las conexiones
            for (WebSocket client : getConnections()) {
                Usuario u = client.getAttachment();
                
                // Verificamos que el usuario sea médico
                if (u != null && (u.getRol() == Usuario.Rol.MEDICO || u.getRol().toString().equals("MEDICO"))) {
                    // ENVIAMOS EL MENSAJE
                    // Quitamos el break para que llegue a todas las sesiones activas del médico
                    client.send("CHAT_DE_PACIENTE:" + texto);
                    entregado = true;
                    medicosActivos++;
                }
            }

            // 3. Feedback en la consola de Eclipse para depuración
            if (entregado) {
                System.out.println("📩 Mensaje entregado a " + medicosActivos + " sesión(es) de médico: " + texto);
            } else {
                System.out.println("⚠️ Intento de envío fallido: No se encontró ningún médico con sesión activa.");
                conn.send("SISTEMA: El médico no está disponible en este momento.");
            }
        }

        // --- 6. CONFIRMAR ASISTENCIA (PACIENTE) ---
     // --- 4. CONFIRMAR ASISTENCIA (CUANDO EL PACIENTE PULSA "IR A CONSULTA") ---
        else if (message.equals("CONFIRMAR_ASISTENCIA")) {
            // 1. Extraemos el nombre del paciente
            Usuario paciente = conn.getAttachment();
            String nombrePaciente = (paciente != null && paciente.getUsername() != null) 
                                    ? paciente.getUsername() : "Paciente Desconocido";
            
            // --- NUEVO: Saludo automático para el Paciente (aparece en su chat como "Tú") ---
            conn.send("SISTEMA: El médico está atendiendo tu consulta ahora mismo.");
            conn.send("CHAT_DE_PACIENTE:👋 He aceptado la llamada. ¡Estoy listo para la consulta!");
            
            // 2. Avisar al médico (o médicos conectados)
            for (WebSocket client : getConnections()) {
                Usuario u = client.getAttachment();
                if (u != null && (u.getRol() == Usuario.Rol.MEDICO || u.getRol().toString().equals("MEDICO"))) {
                    
                    // --- NUEVO: Saludo automático para el Médico (aparece en su chat como "Paciente") ---
                    client.send("CHAT_DE_PACIENTE:👋 He aceptado la llamada. ¡Estoy listo para la consulta!");

                    // 1. OBTENER REPUTACIÓN ACTUAL
                    double[] stats = {0.0, 0.0};
                    try {
                        stats = database.UsuarioDAO.obtenerReputacionActual(u.getUsername());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    
                    // 2. ENVIAR ACTUALIZACIÓN VISUAL DE ESTRELLAS
                    client.send("VALORACION_ACTUALIZADA:" + stats[0] + ":" + (int)stats[1]);

                    // --- TUS FUNCIONALIDADES ORIGINALES ---
                    // Mensaje de sistema visual en el chat del médico
                    client.send("CHAT_DE_PACIENTE: 🟢 " + nombrePaciente + " ha entrado. Redirigiendo...");     
                    
                    // Comando de redirección (Recuerda usar abrirChat(nombre, true) en el JS)
                    client.send("COMANDO:ABRIR_CHAT:" + nombrePaciente);
                }
            }
            System.out.println("✅ Consulta iniciada formalmente: " + nombrePaciente);
        }
        

        // --- 5. LÓGICA DE REENVÍO DE MENSAJES (PARA EL CHAT) ---
        else if (message.startsWith("ENVIAR_AL_MEDICO:")) {
            // 1. Usamos substring en lugar de replace para quitar SOLO el prefijo inicial
            // Esto evita errores si el paciente escribe la palabra clave dentro de su mensaje
            String contenidoChat = message.substring("ENVIAR_AL_MEDICO:".length()).trim();
            
            // 2. Variable para control interno (log)
            int medicosRecibidos = 0;

            for (WebSocket client : getConnections()) {
                Usuario u = client.getAttachment();
                
                // Verificamos que el usuario existe y es médico
                if (u != null && (u.getRol() == Usuario.Rol.MEDICO || u.getRol().toString().equals("MEDICO"))) {
                    // Enviamos el mensaje con el prefijo que espera el JS del médico
                    // Quitamos el espacio extra después de los dos puntos para que el JS lo maneje limpio
                    client.send("CHAT_DE_PACIENTE:" + contenidoChat);
                    medicosRecibidos++;
                }
            }

            // 3. Log de depuración en la consola de Eclipse
            if (medicosRecibidos > 0) {
                System.out.println("📩 Mensaje reenviado a (" + medicosRecibidos + ") médico(s): " + contenidoChat);
            } else {
                System.out.println("⚠️ Intento de chat: No hay médicos conectados con sesión activa.");
            }
        }
        else if (message.startsWith("INICIAR_CONSULTA_MANUAL:")) {
            String nombrePaciente = message.substring("INICIAR_CONSULTA_MANUAL:".length()).trim();
            
            // 1. Buscamos al paciente para obligarle a entrar al chat
            for (WebSocket client : getConnections()) {
                Usuario u = client.getAttachment();
                if (u != null && u.getUsername().equals(nombrePaciente)) {
                    // Le mandamos al paciente el mensaje de sistema y el comando
                    client.send("SISTEMA: El médico ha iniciado la consulta.");
                    client.send("COMANDO:ENTRAR_CONSULTA"); // Esto hará que al paciente se le abra el chat
                }
            }
            
            // 2. Le confirmamos al médico en su propio chat
            conn.send("CHAT_DE_PACIENTE: 🟢 Has iniciado la consulta manualmente con " + nombrePaciente);
            
            System.out.println("⚡ Consulta iniciada manualmente por el médico para: " + nombrePaciente);
        }
        else if (message.startsWith("FINALIZAR_CONSULTA:")) {
            String nombrePaciente = message.substring("FINALIZAR_CONSULTA:".length()).trim();
            
            // Obtenemos el nombre del médico que está realizando la acción
            Usuario medico = conn.getAttachment();
            String nombreMedico = (medico != null) ? medico.getUsername() : "Médico";

            for (WebSocket client : getConnections()) {
                Usuario u = client.getAttachment();
                if (u != null && u.getUsername().equals(nombrePaciente)) {
                    // 1. Aviso textual
                    client.send("SISTEMA: El médico ha finalizado la consulta.");
                    
                    // 2. Comando con el nombre del médico para que el paciente sepa a quién valorar
                    // Formato: COMANDO:CONSULTA_FINALIZADA:NombreDelMedico
                    client.send("COMANDO:CONSULTA_FINALIZADA:" + nombreMedico);
                    break;
                }
            }
            System.out.println("🛑 Consulta terminada por " + nombreMedico + " para: " + nombrePaciente);
        }
        else if (message.startsWith("VALORACION_MEDICO:")) {
            // El mensaje debe llegar como "VALORACION_MEDICO:4.5:DrRodrigo"
            String[] partes = message.split(":");
            
            if (partes.length >= 3) {
                try {
                    double nota = Double.parseDouble(partes[1]);
                    String nombreMedico = partes[2].trim();

                    if (!nombreMedico.isEmpty() && !nombreMedico.equals("undefined")) {
                        // 1. Guardamos en la Base de Datos y calculamos la nueva media
                        double[] stats = database.UsuarioDAO.actualizarYObtenerReputacion(nombreMedico, nota);
                        double nuevaMedia = stats[0];
                        int totalVotos = (int) stats[1];

                        // 2. Buscamos la conexión del médico para actualizar su panel en tiempo real
                        boolean medicoEncontrado = false;
                        for (WebSocket client : getConnections()) {
                            Usuario u = client.getAttachment();
                            
                            // Comparamos el usuario de la conexión con el médico que recibió la nota
                            if (u != null && u.getUsername().equalsIgnoreCase(nombreMedico)) {
                                // Enviamos el comando que tu médico.html debe recibir
                                client.send("VALORACION_ACTUALIZADA:" + nuevaMedia + ":" + totalVotos);
                                medicoEncontrado = true;
                                break;
                            }
                        }

                        System.out.println("⭐ Valoración guardada: " + nombreMedico + " -> Nota: " + nota + " (Nueva Media: " + nuevaMedia + ")");
                        if (!medicoEncontrado) {
                            System.out.println("⚠️ Nota guardada en BD, pero el médico " + nombreMedico + " no está conectado ahora.");
                        }
                        
                        System.out.println("⭐ Valoración guardada: " + nombreMedico + " -> Nota: " + nota + " (Nueva Media: " + nuevaMedia + ")");
                        if(!medicoEncontrado) System.out.println("⚠️ Nota guardada en BD, pero el médico " + nombreMedico + " no está conectado para ver el aviso.");
                    } else {
                        System.err.println("❌ Error: Se recibió valoración pero el nombre del médico está vacío o es indefinido.");
                    }
                    
                } catch (NumberFormatException e) {
                    System.err.println("❌ Error: La nota recibida no es un número válido: " + partes[1]);
                } catch (Exception e) {
                    System.err.println("❌ Error procesando valoración: " + e.getMessage());
                    e.printStackTrace();
                }
            } else {
                System.err.println("❌ Error: Formato de valoración incorrecto. Se esperaba 'VALORACION_MEDICO:nota:nombre'");
            }
        }
    }

    // Método para notificar a cada paciente su lugar real en la fila
    private void actualizarPosicionesCola() {
        int posicion = 1;
        for (WebSocket ws : colaEspera) {
            if (ws.isOpen()) {
                // Enviamos un mensaje tipo: COLA_UPDATE:2:5 (Posición 2 de 5 en total)
                ws.send("COLA_UPDATE:" + posicion + ":" + colaEspera.size());
                posicion++;
            }
        }
    }
    
    
    

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        colaEspera.remove(conn); // Lo quitamos de la cola si se desconecta
        actualizarPosicionesCola();
        System.out.println("❌ Conexión cerrada");
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        ex.printStackTrace();
    }

    @Override
    public void onStart() {
        System.out.println("🚀 Servidor Turnix Web iniciado en puerto 8887");
    }

    public static void main(String[] args) {
        ServidorWeb servidor = new ServidorWeb(8887);
        servidor.start();
    }
}